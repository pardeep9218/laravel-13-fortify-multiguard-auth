<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login | AI Chatbot Builder</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body class="min-h-screen bg-slate-950 text-slate-900 antialiased">

    <main class="grid min-h-screen lg:grid-cols-2">

        {{-- Left: Login form --}}
        <section class="flex items-center justify-center px-6 py-12 sm:px-12">

            <div class="w-full max-w-md">

                <a href="/" class="mb-10 inline-flex items-center gap-3">
                    <span class="flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-600 text-xl font-bold text-white">
                        AI
                    </span>

                    <span class="text-xl font-bold text-white">
                        Chatbot Builder
                    </span>
                </a>

                <h1 class="text-3xl font-bold tracking-tight text-white">
                    Welcome back
                </h1>

                <p class="mt-2 text-sm text-slate-400">
                    Sign in to manage your AI chatbots.
                </p>

                @if (session('status'))
                    <div class="mt-6 rounded-lg bg-emerald-500/10 p-3 text-sm text-emerald-300">
                        {{ session('status') }}
                    </div>
                @endif

                @if ($errors->any())
                    <div class="mt-6 rounded-lg bg-red-500/10 p-3 text-sm text-red-300">
                        <ul class="list-inside list-disc">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form method="POST" action="{{ route('login.store') }}" class="mt-8 space-y-5">
                    @csrf

                    <div>
                        <label for="email" class="mb-2 block text-sm font-medium text-slate-200">
                            Email address
                        </label>

                        <input
                            id="email"
                            name="email"
                            type="email"
                            value="{{ old('email') }}"
                            autocomplete="username"
                            required
                            autofocus
                            class="w-full rounded-xl border border-slate-700 bg-slate-900 px-4 py-3 text-white outline-none transition placeholder:text-slate-500 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                            placeholder="you@company.com"
                        >
                    </div>

                    <div>
                        <div class="mb-2 flex items-center justify-between gap-3">
                            <label for="password" class="text-sm font-medium text-slate-200">
                                Password
                            </label>

                            <a
                                href="{{ route('password.request') }}"
                                class="text-sm text-indigo-400 hover:text-indigo-300"
                            >
                                Forgot password?
                            </a>
                        </div>

                        <input
                            id="password"
                            name="password"
                            type="password"
                            autocomplete="current-password"
                            required
                            class="w-full rounded-xl border border-slate-700 bg-slate-900 px-4 py-3 text-white outline-none transition placeholder:text-slate-500 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                            placeholder="Enter your password"
                        >
                    </div>

                    <label class="flex items-center gap-3 text-sm text-slate-300">
                        <input
                            type="checkbox"
                            name="remember"
                            value="1"
                            class="h-4 w-4 rounded border-slate-600 bg-slate-900 text-indigo-600 focus:ring-indigo-500"
                        >

                        Remember me
                    </label>

                    <button
                        type="submit"
                        class="w-full rounded-xl bg-indigo-600 px-4 py-3 font-semibold text-white transition hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:ring-offset-2 focus:ring-offset-slate-950"
                    >
                        Sign in
                    </button>
                </form>

                <p class="mt-8 text-center text-sm text-slate-400">
                    Don't have an account?

                    <a
                        href="{{ route('register') }}"
                        class="font-semibold text-indigo-400 hover:text-indigo-300"
                    >
                        Create an account
                    </a>
                </p>

            </div>
        </section>

        {{-- Right: Product introduction --}}
        <section class="relative hidden overflow-hidden border-l border-white/10 bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 p-12 lg:flex lg:items-center">

            <div class="relative z-10 mx-auto max-w-lg">

                <div class="mb-8 inline-flex items-center rounded-full border border-indigo-400/30 bg-indigo-400/10 px-4 py-2 text-sm text-indigo-200">
                    AI-powered chatbot creation
                </div>

                <h2 class="text-4xl font-bold leading-tight text-white xl:text-5xl">
                    Turn your website into an intelligent AI assistant.
                </h2>

                <p class="mt-6 text-lg leading-8 text-slate-300">
                    Analyze your website, define your chatbot's purpose, and build a helpful assistant tailored to your business.
                </p>

                <div class="mt-10 space-y-5">

                    @foreach ([
                        'Analyze your website content',
                        'Customize your chatbot with guided questions',
                        'Build a knowledge base for accurate answers',
                        'Track conversations and performance',
                    ] as $feature)

                        <div class="flex items-center gap-3 text-slate-200">
                            <span class="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-400/15 text-sm text-emerald-300">
                                ✓
                            </span>

                            <span>{{ $feature }}</span>
                        </div>

                    @endforeach

                </div>
            </div>

            <div class="pointer-events-none absolute -right-32 -top-32 h-96 w-96 rounded-full bg-indigo-600/20 blur-3xl"></div>

            <div class="pointer-events-none absolute -bottom-40 -left-20 h-96 w-96 rounded-full bg-violet-600/20 blur-3xl"></div>

        </section>

    </main>

</body>
</html>